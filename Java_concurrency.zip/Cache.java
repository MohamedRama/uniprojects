

import java.util.ArrayList;

public class Cache {

	private ArrayList<ArrayList<Object>> randuriInCache = new ArrayList<>();
	
	public void addRowToCache(ArrayList<Object>rand){
		randuriInCache.add(rand);
	}
	
}
