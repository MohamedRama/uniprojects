ALRMDAN MOHAMAD 324CC
greutatea temei  >= (8)
Timp alocat rezolvare: aproape 17 ore.
Implementarea este concentrata pe un design modular ce permite usor exxtinderea aplicatiei (e.g. adaugarea de noi componente precum strategiile
clientului). Prin implementarea design pattern-urilor (e.g. Visitor, Observer) este posibila realizarea acestei arhitecturi.
Implementarea Visitor design pattern se aplica pe clasele ShoppingCart, respectiv Department. O instanta shopping cart poate "vizita"
departamentele in vederea aplicarii unei anumite strategii pe Item-urile din componenta. Adaugarea unui nou departament si implicatiile
asupra ShoppingCart-ului (i.e. Item-urilor din acesta) este astfel transparenta.