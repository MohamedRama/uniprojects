package model;

public interface Observer {

}
