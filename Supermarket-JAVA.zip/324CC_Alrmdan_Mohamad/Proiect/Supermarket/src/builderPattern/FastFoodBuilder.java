package builderPattern;

public class FastFoodBuilder {

	private String jucarie;
	private String bautura;
	
	private String hamburger;
	
	
	public FastFoodBuilder(String jucarie, String bautura) {
		this.jucarie = jucarie;
		this.bautura = bautura;
	}
	
	public FastFoodBuilder hamburger(String hamburger){
		this.setHamburger(hamburger);
		return this;
	}
	
	public FastFood build(){
		return new FastFood(this);
	}

	public String getJucarie() {
		return jucarie;
	}
	

	public String getBautura() {
		return bautura;
	}

	public String getHamburger() {
		return hamburger;
	}

	public void setHamburger(String hamburger) {
		this.hamburger = hamburger;
	}
	
}
