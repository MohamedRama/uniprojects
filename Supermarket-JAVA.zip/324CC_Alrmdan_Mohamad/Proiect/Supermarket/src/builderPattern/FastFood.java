package builderPattern;

public class FastFood {

	private String jucarie;
	private String bautura;
	
	private String hamburger;
	
	
	public FastFood(FastFoodBuilder builder){
		this.jucarie = builder.getJucarie();
		this.bautura = builder.getBautura();
		this.hamburger = builder.getHamburger();
	}


	public String getJucarie() {
		return jucarie;
	}

	public String getHamburger() {
		return hamburger;
	}


	public String getBautura() {
		return bautura;
	}


	@Override
	public String toString() {
		return "FastFood [jucarie=" + jucarie + ", bautura=" + bautura + ", hamburger=" + hamburger + "]";
	}

	
}
