package builderPattern;

public class Main {
	
	public static void main(String[] args) {
		
		FastFoodBuilder happymeal = new FastFoodBuilder("macheta","cola");
		happymeal.setHamburger("cheeseburger");
		FastFood meniu = new FastFood(happymeal);
		
		System.out.println(meniu);
	}
	
}
