package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.News;

public class DataNews {

	
	private List<News> theNews = new ArrayList<>();
	
	
	
	public DataNews(){
		
		System.out.println("CONSTRUCTOR DataNews APELAT... LOADING");
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("DONE LOADING");
	}

	public List<News> getTheNews() {
//		return theNews;
		
		List<News> stiriDB = new ArrayList<>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "");
			ResultSet rezultate = conn.createStatement().executeQuery("select * from news");
			while(rezultate.next()){ // rand cu rand
				News stireDinBD = new News();
				stireDinBD.setId(rezultate.getInt("id")); // coloana cu coloana
				stireDinBD.setContent(rezultate.getString("content")); // coloana cu coloana
				stireDinBD.setTitle(rezultate.getString("title")); // coloana cu coloana
				stiriDB.add(stireDinBD);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return stiriDB;
	}
	
	// TODO: functie delete news (id)
	
}
