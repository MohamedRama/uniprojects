package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

/**
 * 
 * @author Alec Clasa pentru operatii cu MySQL pentru tabelul users
 */
public class DataUser {

	/**
	 * Adaugare user in db (register)
	 * 
	 * @param user
	 */
	public void saveUserToDatabase(User user) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "");
			conn.createStatement().executeUpdate("INSERT INTO users(username, password_) VALUES('" + user.getUsername()
					+ "', '" + user.getPassword() + "')");
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Preluare useri din db
	 * 
	 * @return
	 */
	public List<User> findAllUsersInTheDatabase() {
		List<User> all = new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "");
			ResultSet rezultate = conn.createStatement().executeQuery("SELECT * FROM users");

			while (rezultate.next()) {
				User usr = new User();
				usr.setId(rezultate.getInt("id"));
				usr.setUsername(rezultate.getString("username"));
				usr.setPassword(rezultate.getString("password_"));
				all.add(usr);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}

	public void deleteUser(int unId) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "");
			conn.createStatement().executeUpdate("DELETE FROM users WHERE id = " + unId);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		DataUser data = new DataUser();
		data.deleteUser(103);
	}

}
