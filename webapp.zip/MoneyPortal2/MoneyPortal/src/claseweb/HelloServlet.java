package claseweb;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/kek")
public class HelloServlet extends HttpServlet {
       
    public HelloServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pagina = "<html><head></head><body><h1>Salut man</h1></body></html>";
		response.getWriter().append(pagina);
		System.out.println("SALUT BOSS");
	}



}
