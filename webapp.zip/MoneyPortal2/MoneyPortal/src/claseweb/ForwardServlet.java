package claseweb;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.DataNews;
import model.News;

@WebServlet("/ForwardServlet")
public class ForwardServlet extends HttpServlet {
       
	private DataNews data = new DataNews(); // pastram o referinta la DataNews (o variabila), pentru ca nu e bine sa-i dam de fiecare data new ::: new DataNews(); <--- ia 2,5 secunde
	
    public ForwardServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		List<News> stiri = data.getTheNews();  // luam stirile din baza de date
		request.setAttribute("TOATE_STIRILE", stiri); // le trimitem lui stiri_forward.jsp 
		request.getRequestDispatcher("stiri_frontend.jsp").forward(request, response); // FORWARD
		
//		response.sendRedirect("stiri_frontend.jsp");
	}


}
