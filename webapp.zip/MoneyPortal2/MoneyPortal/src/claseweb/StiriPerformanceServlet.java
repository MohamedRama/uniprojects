package claseweb;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.DataNews;
import model.News;

@WebServlet("/StiriPerformanceServlet")
public class StiriPerformanceServlet extends HttpServlet {
	
	private DataNews data = new DataNews();
       
    public StiriPerformanceServlet() {
        super();
        System.out.println("OBIECT STIRI PERFORMANCE SERVLET CREAT!!!!!>>>><<<<!!!!!");
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		List<News> stiri = data.getTheNews();
		response.getWriter().append("STIRI PERFORMANCE SERVLET INCARCAT");
		response.getWriter().append("STIRI: " + stiri);
		
		response.getWriter().append("<br/>");
		response.getWriter().append("<br/>");
		response.getWriter().append("THE NEWS TABLE:");
		response.getWriter().append("<br/>");
		String tabel = "<table border='10'><tr><td><b>ID</b></td><td><b>Title</b></td><td><b>Content</b></td></tr>";
		for(News n : stiri){
			tabel += "<tr><td>"+n.getId()+"</td><td>"+n.getTitle()+"</td><td><it>"+n.getContent()+"</it></td></tr>";
		}
		tabel += "</table>";
		
		

		response.getWriter().append(tabel);
	}


}
