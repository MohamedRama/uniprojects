package claseweb;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.DataUser;
import model.User;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    public RegisterServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("AI ACCESAT SERVLET-UL DE REGISTER");
		

		String numeUtilizatorTrimisDeUser = request.getParameter("nume_utilizator");
		String parolaTrimisa = request.getParameter("parola_utilizator");
		
		System.out.println("Cineva incearca sa faca register cu " + numeUtilizatorTrimisDeUser + " si parola: " + parolaTrimisa);

		User user = new User();
		user.setUsername(numeUtilizatorTrimisDeUser);
		user.setPassword(parolaTrimisa);
		
		DataUser data = new DataUser();
		
		data.saveUserToDatabase(user);
	}


}
