package app;

public class Persoana {

}
