package app;

import java.util.List;

import data.DataNews;
import model.News;

public class Program {

	public static void main(String[] args) {
		
		DataNews data = new DataNews();
		
		List<News> news = data.getTheNews();
		for(News n : news){
			System.out.println(n.getId() + " " + n.getTitle());
		}
		
	}
	
}
