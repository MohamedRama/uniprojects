package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.News;

public class DataNews {

	
	private List<News> theNews = new ArrayList<>();
	
	
	
	public DataNews(){
//		theNews.add(new News(101, "java is winning", "java is sooo awesome"));
//		theNews.add(new News(102, "economic crysis", "USA is in dire straits"));
		
	}

	public List<News> getTheNews() {
//		return theNews;
		
		List<News> stiriDB = new ArrayList<>();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234");  // password here
			ResultSet rezultate = conn.createStatement().executeQuery("select * from news");
			while(rezultate.next()){ // rand cu rand
				News stireDinBD = new News();
				stireDinBD.setId(rezultate.getInt("id")); // coloana cu coloana
				stireDinBD.setContent(rezultate.getString("content")); // coloana cu coloana
				stireDinBD.setTitle(rezultate.getString("title")); // coloana cu coloana
				stiriDB.add(stireDinBD);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return stiriDB;
	}
	
	// TODO: functie delete news (id)
	public void deleteNews(int id){
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234");
			conn.createStatement().executeUpdate("DELETE FROM news WHERE id = " + id);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
