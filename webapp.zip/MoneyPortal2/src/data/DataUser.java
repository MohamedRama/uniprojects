package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

/**
 * 
 * @author Alec Clasa pentru operatii cu MySQL pentru tabelul users
 */
public class DataUser {

	/**
	 * Adaugare user in db (register)
	 * 
	 * @param user
	 */
	public void saveUserToDatabase(User user) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234");  // password
			conn.createStatement().executeUpdate("INSERT INTO users(username, password_) VALUES('" + user.getUsername()
					+ "', '" + user.getPassword() + "')");  // INSERT -> executeUpdate
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Preluare useri din db
	 * 
	 * @return
	 */
	public List<User> findAllUsersInTheDatabase() {
		List<User> all = new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234"); // password
			ResultSet rezultate = conn.createStatement().executeQuery("SELECT * FROM users");  // SELECT -> executeQuery

			while (rezultate.next()) {
				User usr = new User();
				usr.setId(rezultate.getInt("id"));
				usr.setUsername(rezultate.getString("username"));
				usr.setPassword(rezultate.getString("password_"));
				all.add(usr);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}

	public void deleteUser(int unId) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234"); // password
			conn.createStatement().executeUpdate("DELETE FROM users WHERE id = " + unId);  // DELETE -> executeUpdate
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// update / edit
	public void editUser(User newUserData){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234"); // password
			String query = "UPDATE users SET username = '"+newUserData.getUsername()+"', password_ = '"+newUserData.getPassword()+"' WHERE id = " + newUserData.getId();
			System.out.println("VREM SA EXECUTAM QUERY-ul: " + query);
			conn.createStatement().executeUpdate(query);
		}catch(Exception e){
			e.printStackTrace(); // daca sunt erori ne arata erorile dar nu opreste programul
		}
	}
	
	
	// findUserById(1113); 
	
	public User findUserById(int id){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newsportal", "root", "1234"); // password
			
			String query = "SELECT * FROM users WHERE id = " + id;
			ResultSet rezultate = conn.createStatement().executeQuery(query);
			while(rezultate.next()){
				User user = new User();
				user.setId(rezultate.getInt("id"));
				user.setUsername(rezultate.getString("username"));
				user.setPassword(rezultate.getString("password_"));
				return user;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public static void main(String[] args) {
		DataUser data = new DataUser();
		User someUser = new User();
		someUser.setId(3);
		someUser.setUsername("andy_boss_de_boss");
		someUser.setPassword("123456789");
		data.editUser(someUser);
		
	}

}
